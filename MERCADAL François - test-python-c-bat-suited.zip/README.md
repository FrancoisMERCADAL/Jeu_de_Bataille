# How to run the code:

version of Python used: **3.7.0**

To run the code:
> Open and execute the Python file "bataille.py"

> The output will be display in the console directly


### Answer found after running the code:
> Player1 (Alice) wins after 366 turns

> Player1 won 196 times

> Player2 won 170 times